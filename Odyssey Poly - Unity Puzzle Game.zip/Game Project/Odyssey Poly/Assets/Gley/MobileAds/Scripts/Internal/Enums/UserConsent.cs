namespace Gley.MobileAds.Internal
{
    public enum UserConsent
    {
        Unset = 0,
        Accept = 1,
        Deny = 2
    }
}
