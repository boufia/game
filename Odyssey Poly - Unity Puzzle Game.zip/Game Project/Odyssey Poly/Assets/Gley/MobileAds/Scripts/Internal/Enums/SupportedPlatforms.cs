namespace Gley.MobileAds.Internal
{
    public enum SupportedPlatforms
    {
        Android = 0,
        iOS = 1,
    }
}