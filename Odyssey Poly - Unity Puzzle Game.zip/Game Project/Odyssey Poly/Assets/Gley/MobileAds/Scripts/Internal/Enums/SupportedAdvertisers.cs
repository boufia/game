﻿namespace Gley.MobileAds.Internal
{
    public enum SupportedAdvertisers
    {
        None = 0,
        AdColony = 10,
        Admob = 20,
        AppLovin = 30,
        LevelPlay = 40,
        UnityLegacy = 50,
        Vungle = 60,
    }
}
