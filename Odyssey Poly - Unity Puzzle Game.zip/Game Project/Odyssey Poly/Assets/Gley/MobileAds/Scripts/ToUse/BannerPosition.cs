namespace Gley.MobileAds
{
    public enum BannerPosition
    {
        Bottom,
        BottomLeft,
        BottomRight,
        Center,
        CenterLeft,
        CenterRight,
        Custom,
        Top,
        TopLeft,
        TopRight
    }
}