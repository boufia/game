namespace Gley.MobileAds
{
    public enum BannerType
    {
        Banner,
        Large,
        BannerShort,
        Custom,
        Adaptive,
        IABBanner,
        Leaderboard,
        MediumRectangle,
        Skyscraper,
        Smart
    }
}
