﻿
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;


public class CanvasScript : MonoBehaviour {

	public static CanvasScript instance;

	public GameObject[] lvls;
	void Awake()
	{
		instance = this;
	}
	// Use this for initialization
	void Start () {
		FirstStep ();
	}
		
	
	void FirstStep()
	{
		for (int i = 0; i < lvls.Length; i++) {
			lvls [i].name = (i + 1).ToString();
			lvls[i].transform.GetChild(0).GetComponent<Text>().text = (i + 1).ToString(); 
		}
		CheckingLevelsCompleted ();
	}

	public void LevelBtnPressed()
	{
		string nameofBtn = EventSystem.current.currentSelectedGameObject.name;
		SceneManager.LoadScene (nameofBtn);
	}

	void CheckingLevelsCompleted()
	{
		for (int i = 0; i < lvls.Length; i++) {
			lvls [i].name = (i + 1).ToString();
			lvls[i].transform.GetChild(0).GetComponent<Text>().enabled = false;
			lvls [i].transform.GetChild (1).GetComponent<Image> ().enabled = true;
		}
	}
}
