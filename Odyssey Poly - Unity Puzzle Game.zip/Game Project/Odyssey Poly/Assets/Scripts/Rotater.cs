﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Rotater : MonoBehaviour {

	[SerializeField] float rotationSensitivity;
	public bool checkComplete,effect;
	[SerializeField]public Vector3 rotation;
	 GameObject[] temp;
	int rotatinBasedOnEurlerAngle;
	float xValue = 1;
	public Material testMat;

	void Start()
	{
		RandomPositioning ();
	}

	void Update() {
		
		if (Input.GetMouseButton(0) && !isComplete () && !EventSystem.current.IsPointerOverGameObject()) {
			float horizontal = Input.GetAxis("Mouse X");
			float Vertical = Input.GetAxis ("Mouse Y");
			transform.Rotate(-Vector3.up * horizontal * rotationSensitivity * Time.deltaTime, Space.Self);
			transform.Rotate (-Vector3.right * Vertical * rotationSensitivity * Time.deltaTime, Space.Self);
			//RotatingChildObjects ();
		}
		if (isComplete () && !checkComplete) {
			StartCoroutine ("AfterComplete");
		}
		if (isComplete () && checkComplete && effect) {
			if (xValue > -1) {
				xValue -= 2 * Time.deltaTime;
				AfterCompleteEffect ();
			}
		}
	}

	void RotatingChildObjects()
	{
		for (int i = 0; i < temp.Length; i++) {
			float Vertical = Input.GetAxis ("Mouse Y");
			temp[i].transform.Rotate (-Vector3.right * Vertical * rotationSensitivity * Time.deltaTime, Space.Self);
		}
	}

	bool isComplete()
	{
		if ((transform.rotation.eulerAngles.x<10 )&&(transform.rotation.eulerAngles.x>-10)  )  {
			if ((transform.rotation.eulerAngles.y < 10 && transform.rotation.eulerAngles.y > -10))  {
				rotatinBasedOnEurlerAngle = 1;
				return true;
			}
			else if ((transform.rotation.eulerAngles.y < 190 && transform.rotation.eulerAngles.y > 170))  {
				rotatinBasedOnEurlerAngle = 2;
				return true;
			}
		}

		return false;
	}

	bool checkinginternalParts()
	{
		for (int i = 0; i < temp.Length; i++) {
			if ((temp [i].transform.rotation.eulerAngles.x < 15 && temp [i].transform.rotation.eulerAngles.x > -15) || (temp [i].transform.rotation.eulerAngles.x < 190 && temp [i].transform.rotation.eulerAngles.x > 170)) {
				return true;
			}
		}
		return false;
	}

	List<Vector3> startPositions = new List<Vector3>() ;
	void RandomPositioning()
	{
		int tempint;
		float tempfloat;
		temp = GameObject.FindGameObjectsWithTag ("fish");
		 
		for (int i = 0; i < temp.Length; i++) {
			tempint = Random.Range (-2, 3);
			tempfloat = (float)tempint / 100;
			temp [i].transform.position = new Vector3 (temp [i].transform.position.x, temp [i].transform.position.y, tempfloat);
			startPositions.Add (temp [i].transform.localPosition);
		}
		Vector3 temps = new Vector3 (Random.Range (11, 170), Random.Range (11, 170), Random.Range (11, 170));
		transform.localEulerAngles = temps;
	}


		

	IEnumerator AfterComplete()
	{
		if (!checkComplete) {
			for (int i = 0; i < temp.Length; i++) {
				temp [i].transform.localEulerAngles= Vector3.zero;
			}
			if(rotatinBasedOnEurlerAngle == 1)
				transform.eulerAngles = new Vector3 (0, 0, transform.rotation.eulerAngles.z);
			else if(rotatinBasedOnEurlerAngle == 2)
				transform.eulerAngles = new Vector3 (0, 180, transform.rotation.eulerAngles.z);
				
			yield return new WaitForSeconds (0.3f);
			for (int i = 0; i < temp.Length; i++) {
				temp [i].SetActive (false);
			}
			yield return new WaitForSeconds (0.3f);
			for (int i = 0; i < temp.Length; i++) {
				temp [i].SetActive (true);
			}
			yield return new WaitForSeconds (0.1f);
			if(rotatinBasedOnEurlerAngle == 1)
			iTween.RotateTo (gameObject, iTween.Hash ("x", 0, "y", 0, "z", 0, "time", 1f, "easeType", iTween.EaseType.linear));
			if(rotatinBasedOnEurlerAngle == 2)
				iTween.RotateTo (gameObject, iTween.Hash ("x", 0, "y", 180, "z", 0, "time", 1f, "easeType", iTween.EaseType.linear));
			checkComplete = true;
			yield return new WaitForSeconds (0.3f);
			effect = true;
			AfterCompleteSave ();
			FindObjectOfType<InGame> ().LevelCompleted ();
		}

	}

	void AfterCompleteSave()
	{
		int levelToUnlock = int.Parse(SceneManager.GetActiveScene().name);
	// unlocking levels
		PlayerPrefs.SetInt ((levelToUnlock + 1).ToString(), 1);
	// unlocking Imgaes
		PlayerPrefs.SetInt ("Img" + (levelToUnlock - 1), 1);
	// save
		PlayerPrefs.Save ();
	}
	void AfterCompleteEffect()
	{
		testMat.SetTextureOffset ("_MainTex2", new Vector2 (xValue,0f));
	}

}
