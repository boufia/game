﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {


	[SerializeField] float rotationSensitivity;
	public bool checkComplete;
	[SerializeField]	public Vector3 rotation;

	void Start()
	{
		RandomPositioning ();
	}

	void Update() {
		checkComplete = isComplete ();
		if (Input.GetMouseButton(0) && !checkComplete) {
			float horizontal = Input.GetAxis("Mouse X");
			float Vertical = Input.GetAxis ("Mouse Y");
			transform.Rotate(-Vector3.up * horizontal * rotationSensitivity * Time.deltaTime, Space.Self);
			transform.Rotate (-Vector3.right * Vertical * rotationSensitivity * Time.deltaTime, Space.Self);
		}
		if (checkComplete) {
			transform.eulerAngles = new Vector3 (0, transform.rotation.eulerAngles.y, 0);
			print ("completed");
		}
		Testing ();
	}

	bool isComplete()
	{
		print (rotation);
		if ((transform.rotation.eulerAngles.x < 10 && transform.rotation.eulerAngles.x > -10) || (transform.rotation.eulerAngles.x < 180 && transform.rotation.eulerAngles.x > 170) || (transform.rotation.eulerAngles.x > -180 && transform.rotation.eulerAngles.x < -170)|| (transform.rotation.eulerAngles.x < 190 && transform.rotation.eulerAngles.x > 180) || (transform.rotation.eulerAngles.x > -190 && transform.rotation.eulerAngles.x < -180) )  {
			if ((transform.rotation.eulerAngles.z < 10 && transform.rotation.eulerAngles.z > -10) || (transform.rotation.eulerAngles.z < 180 && transform.rotation.eulerAngles.z > 170) || (transform.rotation.eulerAngles.z > -180 && transform.rotation.eulerAngles.z < -170)|| (transform.rotation.eulerAngles.x < 190 && transform.rotation.eulerAngles.x > 180) || (transform.rotation.eulerAngles.x > -190 && transform.rotation.eulerAngles.x < -180))  {
				print("z");
				return true;
			}
		}
		return false;
	}

	void RandomPositioning()
	{
		int tempint;
		float tempfloat;
		GameObject[] temp = GameObject.FindGameObjectsWithTag ("fish");
		for (int i = 0; i < temp.Length; i++) {
			tempint = Random.Range (-2, 3);
			tempfloat = (float)tempint / 100;
			temp [i].transform.position = new Vector3 (temp [i].transform.position.x, tempfloat, temp [i].transform.position.z);
		}
		Vector3 temps = new Vector3 (Random.Range (0, 180), Random.Range (0, 180), Random.Range (0, 180));
		transform.localEulerAngles = temps;
	}
		
	public void restart()
	{
		SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
	}

	float xAngle,yAngle,eulerAngY,eulerAngX;
	void Testing()
	{
		rotation = transform.localEulerAngles;
	}
}
