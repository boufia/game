﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class InGame : MonoBehaviour {

	public static InGame instance;

	void Awake()
	{
		instance = this;
	}
	
	public void restart()
	{
		SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
	}

	public void Continue()
	{
        Ads.instance.showAd();
        Home();
	}

	public void Home()
	{
		SceneManager.LoadScene ("StartMain");
	}

	public void LevelCompleted()
	{
		GameObject.Find ("Continue").GetComponent<Image>().enabled = true;
		GameObject.Find ("Continue").GetComponent<Button> ().enabled = true;
	}
}
