using UnityEngine;

public class Ads : MonoBehaviour
{
    public static Ads instance;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        DontDestroyOnLoad(instance);
    }

    void Start()
    {
        Gley.MobileAds.API.Initialize();
    }

    public void showAd()
    {
        Gley.MobileAds.API.ShowInterstitial();
    }
}
